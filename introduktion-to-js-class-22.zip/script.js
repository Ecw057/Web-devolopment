// javascript language is used to add functionality to the html and css webpage.  It is also to creare games.
//two ways to give javascript: internal javascript and external javascript
//internal javascript: Here we do coding in html file in the script tag.
//external javascript: Here we create a separate script.js file and then connect it with html file using script tag.